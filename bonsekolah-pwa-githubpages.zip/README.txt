BONSEKOLAH PWA — PANDUAN UPLOAD KE GITHUB PAGES

File yang ada di folder ini:
  index.html   → aplikasi utama
  manifest.json → manifest PWA
  sw.js         → service worker (offline)
  icon-192.png  → ikon HP
  icon-512.png  → ikon splash screen

═══════════════════════════════════════
LANGKAH UPLOAD KE GITHUB PAGES (GRATIS)
═══════════════════════════════════════

1. Buka github.com → login atau daftar gratis
2. Klik tombol "+" → "New repository"
3. Nama repository: bonsekolah  (bebas)
4. Pilih: Public
5. Klik "Create repository"
6. Di halaman repository, klik "uploading an existing file"
7. Drag & drop SEMUA file dari folder ini (index.html, manifest.json, sw.js, icon-192.png, icon-512.png)
8. Klik "Commit changes"
9. Buka Settings → Pages → Source: pilih "main" → folder "/ (root)" → Save
10. Tunggu 1-2 menit → link Anda muncul, contoh:
    https://namausergithub.github.io/bonsekolah/

SELESAI. Kirim link itu ke pembeli lewat WhatsApp.

═══════════════════════════════════════
CARA INSTALL DI HP ANDROID (UNTUK PEMBELI)
═══════════════════════════════════════

1. Buka link di Chrome Android
2. Chrome otomatis muncul notif "Tambahkan ke layar utama"
   ATAU ketuk ikon titik tiga (⋮) → "Tambahkan ke layar utama"
3. Ketuk "Tambah"
4. Ikon BonSekolah muncul di layar utama HP
5. Buka dari ikon → langsung masuk tanpa browser, offline sepenuhnya

Catatan:
- Internet hanya dibutuhkan SEKALI saat pertama buka link
- Setelah install, data tersimpan di HP, tidak perlu internet lagi
- Data tidak dikirim ke mana pun
